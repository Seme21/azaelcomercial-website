
<!-- ========================== Footer ===================== -->

<footer class="footer">
    <div class="container footer_container">
        <div class="footer_1">
            <a href="index.php" class="footer_logo">
                <h4> Azael Printing</h4>
            </a>
            <p>
                Azael is a printing business that offers high-quality products and services. 
                We offer custom printing, design, and delivery, so you can get the perfect  
                product for any occasion. We use the latest technology to ensure the  
                highest quality prints and fast turnaround times. Get in touch today to  
                see how we can help you!
            </p>
        </div>

        <div class="footer_2">
            <h4>Importat Links</h4>
            <ul class="imptlinks">
                <li><a href="index.php">Home</a></li>
                <li><a href="index.php">About</a></li>
                <li><a href="index.php">Services</a></li>
                <li><a href="index.php">Contac Us</a></li>
                <li><a href="index.php">Developer</a></li>
            </ul>
        </div>

        <div class="footer_3">
            <h4>Terms & Conditions</h4>
            <ul class="terconds">
                <li><a href="privacyp.php">Privacy Policy</a></li>
                <li><a href="termscd.php">Terms and Conditions</a></li>
                <li><a href="refundp.php">Refund Policy</a></li>
            </ul>
        </div>

        <div class="footer_4">
            <h4>Address </h4>
            <div>
                <p><i class="uil uil-location-point"> Remet Tabor Oda Tawor, infront of St.Georgies,Pyasa, Addis Ababa,
                        Ethiopia.</i> </p>
                <p><i class="uil uil-phone-volume">+25141413132</i></p>
                <p><i class="uil uil-phone-volume">+251703792447</i></p>
                <p><i class="uil uil-envelopes">info@azaelprinting.com</i></p>
            </div>

            <ul class="footer_socialmds">
                <li><a href="#"><i class="uil uil-whatsapp"></i> </a> </li>
                <li><a href="#"><i class="uil uil-facebook-f"></i> </a> </li>
                <li><a href="#"><i class="uil uil-twitter-alt"></i> </a> </li>
                <li><a href="#"><i class="uil uil-telegram-alt"></i> </a> </li>
                <li><a href="#"><i class="uil uil-linkedin"></i> </a> </li>
            </ul>
        </div>
    </div>

    <div class="footer_copyright">
        <small>Copy right &copy; AZAEL PRINTING protected under law! <a href="https://t.me/Yotod776">Develope by
                Semahegn Tilahun D.</a> </small>
    </div>
</footer>

<!-- ========================== end of Footer ===================== -->
<!-- <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script> -->
<script src="../dist/script/main.js"></script>

<!-- <script>
var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 30,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    // change while width is >=600px
    breakpoints: {
        600: {
            slidesPerView: 2
        }
    }
});
</script> -->

</body>

</html>