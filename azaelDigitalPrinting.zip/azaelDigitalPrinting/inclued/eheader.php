<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- web titile icon -->
    <link class="iconT" rel="icon" type="image/png" href="../image/logoicon.png" />
    <!-- a title for the website -->
    <title>Azeal Printing Service</title>
    <!-- link for iconscout CDN -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.6/css/unicons.css">
    <!-- link for google fonts (montserrat) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap">
    <!-- link to a style -->
    <link rel="stylesheet" href="../dist/css/style.css">
    <link rel="stylesheet" href="../dist/css/about.css">
    <link rel="stylesheet" href="../dist/css/contact.css">
    
    <!-- link for swiper js
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" /> -->

</head>


<body>
    <div class="container-fluid">
        <div class="container infohead">
            <div class="textwidget left">
                <!-- <p> -->
                <span style="font-size: 14px; color: #ffffffbf;">call us:</span> &nbsp;
                <a href="tel:+25141413132">+25141413132</a>
                <span style="font-size: 14px; color: #ffffffbf;"> email: </span> &nbsp;
                <a href="mailto:info@azaelprinting.com">info@azaelprinting.com</a>
            </div>
            <div class="textwidget right">
                <!-- <p> -->
                <span style="font-size: 14px; color: #ffffffbf;">follow us:</span>&nbsp; &nbsp;
                <span style="font-size: 13px; letter-spacing: 0.03em;">
                    <strong>
                        <a class="qodef-underline-link" href="https://www.facebook.com/azaelpplc.printing/"
                            target="_blank" rel="noopener">FB.</a>&nbsp; &nbsp;&nbsp;
                        <a class="qodef-underline-link" href="https://www.instagram.com/azaelpplc.printing/"
                            target="_blank" rel="noopener">IG.</a></strong>
                </span>
                <!-- </p> -->
            </div>
        </div>
    </div>

    <nav>
        <div class="container nav_container">
            <a href="index.php">
                <h4>Azael Printing</h4>
            </a>
            <ul class="nav_menu">
                <li><a href="index.php"><i class="uil uil-home">Home</i> </a></li>
                <li><a href="about.php"><i class="uil uil-books">About</i> </a></li>
                <li><a href="service.php"><i class="uil uil-file-share-alt">Service</i> </a></li>
                <li><a href="contact.php"><i class="uil uil-comments">ContactUs</i> </a></li>
                <!-- <div class="auth">
                    <li><a href="index.php">Login</a></li>
                    <li><a href="index.php">Signup</a></li>                    
                </div> -->

            </ul>
            <!-- <div class="searchbox">
                    <input class="qodef-search-opener-text"> <a href=""><i class="uil uil-search" aria-placeholder="Please search here...">Search</i></a></input>
            </div> -->
            <button id="open-menu-btn"><i class="uil uil-bars"></i> </button>
            <button id="close-menu-btn"><i class="uil uil-multiply"></i> </button>
        </div>
    </nav>