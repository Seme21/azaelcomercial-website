
<?php
include("../inclued/eheader.php")
?>
<style>
    .services{
        margin-top: 1rem;
    }
</style> 
<!-- ========================== end of Available service categories ===================== -->
<section class="services" >
    <div class="container services_container">
        <article class="service">
            <div class="service_image">
                <img src="../image/00.png" alt="not found">
            </div>
            <div class="service_info">
                <h4>Graphics Design and printing</h4>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Totam dolorem ...
                </p>
                <a href="services.php" class="btn btn-primary">Read More</a>
            </div>
        </article>

        <article class="service">
            <div class="service_image">
                <img src="../image/01.jpg" alt="not found">
            </div>
            <div class="service_info">
                <h4>Graphics Design and printing</h4>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Totam dolorem ...
                </p>
                <a href="services.php" class="btn btn-primary">Read More</a>
            </div>
        </article>

        <article class="service">
            <div class="service_image">
                <img src="../image/04.png" alt="not found">
            </div>
            <div class="service_info">
                <h4>Graphics Design and printing</h4>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Totam dolorem ...
                </p>
                <a href="services.php" class="btn btn-primary">Read More</a>
            </div>
        </article>

        <article class="service">
            <div class="service_image">
                <img src="../image/04.jpg" alt="not found">
            </div>
            <div class="service_info">
                <h4>Graphics Design and printing</h4>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Totam dolorem ...
                </p>
                <a href="services.php" class="btn btn-primary">Read More</a>
            </div>
        </article>

        <article class="service">
            <div class="service_image">
                <img src="../image/00.jpg" alt="not found">
            </div>
            <div class="service_info">
                <h4>Graphics Design and printing</h4>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Totam dolorem ...
                </p>
                <a href="services.php" class="btn btn-primary">Read More</a>
            </div>
        </article>

        <article class="service">
            <div class="service_image">
                <img src="../image/logo.png" alt="not found">
                <img src="../image/logo.png" alt="not found">
                <img src="../image/logo.png" alt="not found">
            </div>
            <div class="service_info">
                <h4>Graphics Design and printing</h4>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Totam dolorem ...
                </p>
                <a href="services.php" class="btn btn-primary">Read More</a>
            </div>
        </article>
    </div>
</section>
<!-- ========================== end of available service category ===================== -->

<?php
include("../inclued/efooter.php")
?>




