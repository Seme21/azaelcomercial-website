<?php
include("../inclued/eheader.php");

?>
<script>
    var phone_number = window.intlTelInput(document.querySelector("#phone_number"), {
    separateDialCode: true,
    preferredCountries:["in"],
    hiddenInput: "full",
    utilsScript: "//cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/utils.js"
    });

    $("form").submit(function() {
    var full_number = phone_number.getNumber(intlTelInputUtils.numberFormat.E164);
    $("input[name='phone_number[full]'").val(full_number);
    alert(full_number)
    
    });
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdn.tutorialjinni.com/intl-tel-input/17.0.8/css/intlTelInput.css"/>
<script src="https://cdn.tutorialjinni.com/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>

<!-- <link href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/css/intlTelInput.min.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/intlTelInput.min.js"></script> -->


<style>
.success {
    background-color: #9fd2a1;
    padding: 5px 10px;
    color: #326b07;
    text-align: center;
    border-radius: 3px;
    font-size: 14px;
    margin-top: 10px;
}
</style>
<section class="contact">
    <div class="container contact_container">
        <aside class="contact_aside">
            <div class="aside_image">
                <img src="../image/contact/contactUs.png" alt="not found">
            </div>
            <h2>Contact Us</h2>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Architecto sunt aut earum quasi ab odit fuga
                assumenda rem iure reprehenderit obcaecati, eaque repellat sed et. </p>
            <ul class="contact_details">
                <li>
                    <i class="uil uil-phone-times"></i>
                    <h5>+251941413132</h5>
                </li>
                <li>
                    <i class="uil uil-envelop"></i>
                    <h5>info@azaelprinting.com</h5>
                </li>
                <li>
                    <i class="uil uil-location-point"></i>
                    <h5>Addis Ababa, Ethiopia</h5>
                </li>
            </ul>
            <ul class="contact_socialmds">
                <li> <a href="https://facebook.com"> <i class="uil uil-facebook-f"></i> </a> </li>
                <li> <a href="https://instagram.com"> <i class="uil uil-instagram"></i> </a> </li>
                <li> <a href="https://twitter.com"> <i class="uil uil-twitter"></i> </a> </li>
                <li> <a href="https://linkedin.com"> <i class="uil uil-linkedin-alt"></i> </a> </li>
            </ul>
        </aside>
        <!-- phpp email Send -->
        <?php
        if(!empty($_POST["submit"])) {
            $userName = $_POST["firstName"];
            $lastName = $_POST["lastName"];
            $userPhone = $_POST["userPhone"];

            $userEmail = $_POST["userEmailAddress"];
            $userMessage = $_POST["userMessage"];
            $toEmail = "yegnabetsew@gmail.com";
        
            $mailHeaders = "Name: " . $firstName .$lastName;
            "\r\n Email: ". $userEmail  . 
            "\r\n Phone: ". $userPhone  . 
            "\r\n Message: " . $userMessage . "\r\n";

            if(mail($toEmail, $firstName .$lastName, $mailHeaders)) {
                $message = "Your contact information is received successfully.";
            }
        }
        ?>
        <!-- php -->
        <form method="post" class="contact_form">
            <h6 class="error">* required field</h6>
            <div class="form_name">
                <input type="text" name="firstName" placeholder="Your First Name" required>
                <input type="text" name="lastName" placeholder="Your Last Name" required>
            </div>
            <!-- <div class="form_name"> -->
            <input name="userPhone" type="" id="phone" name="userPhone" placeholder="Your Phone number" requiredd>
            <script>
                var input = document.querySelector("#phone");
                window.intlTelInput(input, {
                    separateDialCode: true,
                    excludeCountries: ["in", "il"],
                    preferredCountries: ["ru", "jp", "pk", "no"]
                });
            </script>
            <!-- <input type="number" name="userPhone" placeholder="Your Phone number " required>
            
            </div> -->
            <input type="email" name="userEmailAddress" placeholder="Your Email Address">
            <textarea name="userMessage" id="" cols="30" rows="10" placeholder="Please Type Your Message Here ..."
                required></textarea>
            <input type="submit" name="send" class="btn btn-primary" value="Submit" >
            <!-- <div class="form_name">
                Please Select Your Gender:
                <input type="radio" name="gender" <?php if (isset($gender) && $gender=="female") echo "checked";?>
                    value="female">Female
                <input type="radio" name="gender" <?php if (isset($gender) && $gender=="male") echo "checked";?>
                    value="male">Male
                <input type="radio" name="gender" <?php if (isset($gender) && $gender=="other") echo "checked";?>
                    value="other">Other
                <h6 class="error">* <?php echo $genderErr;?></h6>
            </div> -->
            <?php if (! empty($message)) {?>
            <div class='success'>
                <strong><?php echo $message; ?> </strong>
            </div>
            <?php } ?>
        </form>
    </div>
</section>

<?php
include("../inclued/efooter.php");
?>


