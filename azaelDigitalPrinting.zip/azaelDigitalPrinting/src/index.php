<?php
include("../inclued/header.php")
?>

<!-- ========================== code for header section starting ===================== -->
<header>
    <div class="container header_container">
        <div class="header_left">
            <h1>Print Easily, Efficiently and 'SMART'LY with Us. Just now! Bring your idea to live now! </h1>
            <p>
                Azael is a printing business that offers high-quality products and services.
                We offer custom printing, design, and delivery, so you can get the perfect
                product for any occasion. We use the latest technology to ensure the
                highest quality prints and fast turnaround times. Get in touch today to
                see how we can help you!
            </p>
            <a href="courses.php" class="btn btn-primary">Get Started</a>
        </div>
        <div class="header_right">
            <div class="header_right-image">
                <img src="../image/logo.png" alt="not found">
                <img src="../image/03.jpg" alt="image not found">
            </div>
        </div>
    </div>
</header>

<!-- ========================== code for header section end ===================== -->
<section class="categories">
    <div class="container categories_container">
        <div class="categories_left">
            <hr>
            <h1>Service Categories</h1>
            <p>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                Aperiam eaque quidem, architecto dolor omnis fugiat explicabo
                laudantium at, vel repellendus hic cumque suscipit,
                tempore sequi tenetur soluta culpa doloremque dicta?
            </p>
            <a href="#" class="btn">Read More</a>
        </div>

        <div class="categories_right">
            <article class="category">
                <span class="category_icon">
                    <i class="uil uil-bitcoin-circle"></i>
                </span>
                <h5>Digital Printings</h5>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                    Provident autem minus ducimus,</p>
            </article>

            <article class="category">
                <span class="category_icon">
                    <i class="uil uil-bitcoin-circle"></i>
                </span>
                <h5>Banner Printings</h5>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                    Provident autem minus ducimus, </p>
            </article>

            <article class="category">
                <span class="category_icon">
                    <i class="uil uil-bitcoin-circle"></i>
                </span>
                <h5>Bilboard Printings</h5>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                    Provident autem minus ducimus,</p>
            </article>

            <article class="category">
                <span class="category_icon">
                    <i class="uil uil-bitcoin-circle"></i>
                </span>
                <h5>Sticker Printings</h5>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                    Provident autem minus ducimus,</p>
            </article>

            <article class="category">
                <span class="category_icon">
                    <i class="uil uil-bitcoin-circle"></i>
                </span>
                <h5>Digital Printings</h5>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                    Provident autem minus ducimus, </p>
            </article>

            <article class="category">
                <span class="category_icon">
                    <i class="uil uil-bitcoin-circle"></i>
                </span>
                <h5>Digital Printings</h5>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                    Provident autem minus ducimus, </p>
            </article>

        </div>
    </div>
</section>

<!-- ========================== end of service category ===================== -->
<!-- አዛኤል። እግዚአብሔር ያያል!  -->
<!-- ========================== end of Available service categories ===================== -->
<section class="services">
    <h2>Recent Productions </h2>
    <div class="container services_container">
        <article class="service">
            <div class="service_image">
                <img src="../image/00.png" alt="not found">
            </div>
            <div class="service_info">
                <h4>Graphics Design and printing</h4>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Totam dolorem ...
                </p>
                <a href="services.php" class="btn btn-primary">Read More</a>
            </div>
        </article>

        <article class="service">
            <div class="service_image">
                <img src="../image/01.jpg" alt="not found">
            </div>
            <div class="service_info">
                <h4>Graphics Design and printing</h4>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Totam dolorem ...
                </p>
                <a href="services.php" class="btn btn-primary">Read More</a>
            </div>
        </article>

        <article class="service">
            <div class="service_image">
                <img src="../image/04.png" alt="not found">
            </div>
            <div class="service_info">
                <h4>Graphics Design and printing</h4>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Totam dolorem ...
                </p>
                <a href="services.php" class="btn btn-primary">Read More</a>
            </div>
        </article>

        <article class="service">
            <div class="service_image">
                <img src="../image/04.jpg" alt="not found">
            </div>
            <div class="service_info">
                <h4>Graphics Design and printing</h4>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Totam dolorem ...
                </p>
                <a href="services.php" class="btn btn-primary">Read More</a>
            </div>
        </article>

        <article class="service">
            <div class="service_image">
                <img src="../image/00.jpg" alt="not found">
            </div>
            <div class="service_info">
                <h4>Graphics Design and printing</h4>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Totam dolorem ...
                </p>
                <a href="services.php" class="btn btn-primary">Read More</a>
            </div>
        </article>

        <article class="service">
            <div class="service_image">
                <img src="../image/logo.png" alt="not found">
                <img src="../image/logo.png" alt="not found">
                <img src="../image/logo.png" alt="not found">
            </div>
            <div class="service_info">
                <h4>Graphics Design and printing</h4>
                <p>
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Totam dolorem ...
                </p>
                <a href="services.php" class="btn btn-primary">Read More</a>
            </div>
        </article>
    </div>
</section>
<!-- ========================== end of available service category ===================== -->

<!-- ========================== related searchs ===================== -->
<section class="rsrchs">
    <h2>Related Searchs ... </h2>
    <div class="container rsrchs_container">
        <article class="rsrch">
            <div class="faq_icon"><i class="uil uil-plus"></i> </div>
            <div class="search_result">
                <h4>How do I know the right services available for me?</h4>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ullam possimus nemo,
                    voluptate quam error dolorem necessitatibus veniam quod? Voluptatum, pariatur
                    asperiores iure assumenda dolore consequatur minima porro quia nulla sapiente!
                </p>
            </div>
        </article>

        <article class="rsrch">
            <div class="rsrch_icon"><i class="uil uil-plus"></i> </div>
            <div class="search_result">
                <h4>How do I know the right services available for me?</h4>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ullam possimus nemo,
                    voluptate quam error dolorem necessitatibus veniam quod? Voluptatum, pariatur
                    asperiores iure assumenda dolore consequatur minima porro quia nulla sapiente!
                </p>
            </div>
        </article>

        <article class="rsrch">
            <div class="rsrch_icon"><i class="uil uil-plus"></i> </div>
            <div class="search_result">
                <h4>How do I know the right services available for me?</h4>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ullam possimus nemo,
                    voluptate quam error dolorem necessitatibus veniam quod? Voluptatum, pariatur
                    asperiores iure assumenda dolore consequatur minima porro quia nulla sapiente!
                </p>
            </div>
        </article>

        <article class="rsrch">
            <div class="rsrch_icon"><i class="uil uil-plus"></i> </div>
            <div class="search_result">
                <h4>How do I know the right services available for me?</h4>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ullam possimus nemo,
                    voluptate quam error dolorem necessitatibus veniam quod? Voluptatum, pariatur
                    asperiores iure assumenda dolore consequatur minima porro quia nulla sapiente!
                </p>
            </div>
        </article>

        <article class="rsrch">
            <div class="rsrch_icon"><i class="uil uil-plus"></i> </div>
            <div class="search_result">
                <h4>How do I know the right services available for me?</h4>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ullam possimus nemo,
                    voluptate quam error dolorem necessitatibus veniam quod? Voluptatum, pariatur
                    asperiores iure assumenda dolore consequatur minima porro quia nulla sapiente!
                </p>
            </div>
        </article>

        <article class="rsrch">
            <div class="rsrch_icon"><i class="uil uil-plus"></i> </div>
            <div class="search_result">
                <h4>How do I know the right services available for me?</h4>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ullam possimus nemo,
                    voluptate quam error dolorem necessitatibus veniam quod? Voluptatum, pariatur
                    asperiores iure assumenda dolore consequatur minima porro quia nulla sapiente!
                </p>
            </div>
        </article>

        <article class="rsrch">
            <div class="rsrch_icon"><i class="uil uil-plus"></i> </div>
            <div class="search_result">
                <h4>How do I know the right services available for me?</h4>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ullam possimus nemo,
                    voluptate quam error dolorem necessitatibus veniam quod? Voluptatum, pariatur
                    asperiores iure assumenda dolore consequatur minima porro quia nulla sapiente!
                </p>
            </div>
        </article>

        <article class="rsrch">
            <div class="rsrch_icon"><i class="uil uil-plus"></i> </div>
            <div class="search_result">
                <h4>How do I know the right services available for me?</h4>
                <p>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ullam possimus nemo,
                    voluptate quam error dolorem necessitatibus veniam quod? Voluptatum, pariatur
                    asperiores iure assumenda dolore consequatur minima porro quia nulla sapiente!
                </p>
            </div>
        </article>
    </div>
</section>
<!-- ========================== end of available service category ===================== -->

<!-- =====================class="swiper-wrapper"===== the begining of custemer testimonial ===================== -->
<section class="container testimonials_contaier mySwiper">
    <h2>Customers' Testimonials </h2>
    <div class="swiper-wrapper">
        <article class="testimonial swiper-slide">
            <div class="avater">
                <img src="../image/userTestimonial/03.jpg" alt="not found">
            </div>
            <div class="testimonial_info">
                <h5>Woynishet Abje</h5>
                <small>Receptionist</small>
            </div>
            <div class="testimonial_body">
                <p>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                    Id velit aut officia iure esse sit vero. Eaque soluta
                    pariatur impedit aliquam, quibusdam aliquid eos quam
                    accusantium porro nisi maiores placeat?
                </p>
            </div>
        </article>

        <article class="testimonial swiper-slide">
            <div class="avater">
                <img src="../image/userTestimonial/01.jpg" alt="not found">
            </div>
            <div class="testimonial_info">
                <h5>Feven Eysayas</h5>
                <small>Cloth Merchant</small>
            </div>
            <div class="testimonial_body">
                <p>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                    Id velit aut officia iure esse sit vero. Eaque soluta
                    pariatur impedit aliquam, quibusdam aliquid eos quam
                    accusantium porro nisi maiores placeat?
                </p>
            </div>
        </article>

        <article class="testimonial swiper-slide">
            <div class="avater">
                <img src="../image/userTestimonial/00.jpg" alt="not found">
            </div>
            <div class="testimonial_info">
                <h5>Elsabet Getu</h5>
                <small>Shopkeeper</small>
            </div>
            <div class="testimonial_body">
                <p>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                    Id velit aut officia iure esse sit vero. Eaque soluta
                    pariatur impedit aliquam, quibusdam aliquid eos quam
                    accusantium porro nisi maiores placeat?
                </p>
            </div>
        </article>

        <article class="testimonial swiper-slide">
            <div class="avater">
                <img src="../image/userTestimonial/002.jpg" alt="not found">
            </div>
            <div class="testimonial_info">
                <h5>Semahegn Tilahun</h5>
                <small>Softwer Developer</small>
            </div>
            <div class="testimonial_body">
                <p>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                    Id velit aut officia iure esse sit vero. Eaque soluta
                    pariatur impedit aliquam, quibusdam aliquid eos quam
                    accusantium porro nisi maiores placeat?
                </p>
            </div>
        </article>
    </div>
    <div class="swiper-pagination"></div>
</section>
<!-- ========================== end of acustomer testimonial ===================== -->




<div class="ht_ctc_style ht_ctc_chat_style">
    <div style="display: flex; justify-content: center; align-items: center;  " class="ctc-analytics">
        <p class="ctc-analytics ctc_cta ctc_cta_stick ht-ctc-cta  ht-ctc-cta-hover "
            style="padding: 0px 16px; line-height: 1.6; font-size: 15px; background-color: rgb(37, 211, 102); color: rgb(255, 255, 255); border-radius: 10px; margin: 0px 10px; order: 0; display: none;">
            WhatsApp us</p>
        <svg style="pointer-events:none; display:block; height:50px; width:50px;" width="50px" height="50px"
            viewBox="0 0 1024 1024">
            <defs>
                <path id="htwasqicona-chat"
                    d="M1023.941 765.153c0 5.606-.171 17.766-.508 27.159-.824 22.982-2.646 52.639-5.401 66.151-4.141 20.306-10.392 39.472-18.542 55.425-9.643 18.871-21.943 35.775-36.559 50.364-14.584 14.56-31.472 26.812-50.315 36.416-16.036 8.172-35.322 14.426-55.744 18.549-13.378 2.701-42.812 4.488-65.648 5.3-9.402.336-21.564.505-27.15.505l-504.226-.081c-5.607 0-17.765-.172-27.158-.509-22.983-.824-52.639-2.646-66.152-5.4-20.306-4.142-39.473-10.392-55.425-18.542-18.872-9.644-35.775-21.944-50.364-36.56-14.56-14.584-26.812-31.471-36.415-50.314-8.174-16.037-14.428-35.323-18.551-55.744-2.7-13.378-4.487-42.812-5.3-65.649-.334-9.401-.503-21.563-.503-27.148l.08-504.228c0-5.607.171-17.766.508-27.159.825-22.983 2.646-52.639 5.401-66.151 4.141-20.306 10.391-39.473 18.542-55.426C34.154 93.24 46.455 76.336 61.07 61.747c14.584-14.559 31.472-26.812 50.315-36.416 16.037-8.172 35.324-14.426 55.745-18.549 13.377-2.701 42.812-4.488 65.648-5.3 9.402-.335 21.565-.504 27.149-.504l504.227.081c5.608 0 17.766.171 27.159.508 22.983.825 52.638 2.646 66.152 5.401 20.305 4.141 39.472 10.391 55.425 18.542 18.871 9.643 35.774 21.944 50.363 36.559 14.559 14.584 26.812 31.471 36.415 50.315 8.174 16.037 14.428 35.323 18.551 55.744 2.7 13.378 4.486 42.812 5.3 65.649.335 9.402.504 21.564.504 27.15l-.082 504.226z">
                </path>
            </defs>
            <linearGradient id="htwasqiconb-chat" gradientUnits="userSpaceOnUse" x1="512.001" y1=".978" x2="512.001"
                y2="1025.023">
                <stop offset="0" stop-color="#61fd7d"></stop>
                <stop offset="1" stop-color="#2bb826"></stop>
            </linearGradient>
            <use xlink:href="#htwasqicona-chat" overflow="visible" style="fill: url(#htwasqiconb-chat)"
                fill="url(#htwasqiconb-chat)"></use>
            <g>
                <path style="fill: #FFFFFF;" fill="#FFF"
                    d="M783.302 243.246c-69.329-69.387-161.529-107.619-259.763-107.658-202.402 0-367.133 164.668-367.214 367.072-.026 64.699 16.883 127.854 49.017 183.522l-52.096 190.229 194.665-51.047c53.636 29.244 114.022 44.656 175.482 44.682h.151c202.382 0 367.128-164.688 367.21-367.094.039-98.087-38.121-190.319-107.452-259.706zM523.544 808.047h-.125c-54.767-.021-108.483-14.729-155.344-42.529l-11.146-6.612-115.517 30.293 30.834-112.592-7.259-11.544c-30.552-48.579-46.688-104.729-46.664-162.379.066-168.229 136.985-305.096 305.339-305.096 81.521.031 158.154 31.811 215.779 89.482s89.342 134.332 89.312 215.859c-.066 168.243-136.984 305.118-305.209 305.118zm167.415-228.515c-9.177-4.591-54.286-26.782-62.697-29.843-8.41-3.062-14.526-4.592-20.645 4.592-6.115 9.182-23.699 29.843-29.053 35.964-5.352 6.122-10.704 6.888-19.879 2.296-9.176-4.591-38.74-14.277-73.786-45.526-27.275-24.319-45.691-54.359-51.043-63.543-5.352-9.183-.569-14.146 4.024-18.72 4.127-4.109 9.175-10.713 13.763-16.069 4.587-5.355 6.117-9.183 9.175-15.304 3.059-6.122 1.529-11.479-.765-16.07-2.293-4.591-20.644-49.739-28.29-68.104-7.447-17.886-15.013-15.466-20.645-15.747-5.346-.266-11.469-.322-17.585-.322s-16.057 2.295-24.467 11.478-32.113 31.374-32.113 76.521c0 45.147 32.877 88.764 37.465 94.885 4.588 6.122 64.699 98.771 156.741 138.502 21.892 9.45 38.982 15.094 52.308 19.322 21.98 6.979 41.982 5.995 57.793 3.634 17.628-2.633 54.284-22.189 61.932-43.615 7.646-21.427 7.646-39.791 5.352-43.617-2.294-3.826-8.41-6.122-17.585-10.714z">
                </path>
            </g>
        </svg>
    </div>
</div>
<?php
include("../inclued/footer.php")
?>